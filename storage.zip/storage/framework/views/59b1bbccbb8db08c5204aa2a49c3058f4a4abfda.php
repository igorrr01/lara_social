<?php echo e($slot); ?>

<?php /**PATH E:\OpenServer2\domains\laravel7.project\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>