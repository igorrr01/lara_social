<?php if(auth()->guard()->check()): ?>


<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

     <section class="content">
       <div class="card-header">
        <div class="row justify-content-center" >
          <div class="col-md-10">
            <!-- Box Comment -->
            <div class="card card-widget">
              <div class="card-header" >
                <h2 class="card-title"><b>Пользователи онлайн</b></h2></div>
                  <div class="card-body">
                   <?php $__currentLoopData = $users_online; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $uuser): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <p class="card-text">
                    <?php if($uuser->avatar): ?>
                    <img src="/storage/app/<?php echo e($uuser->avatar); ?>"  alt="User Image" class="rounded-circle" height="20" width="20">
                    <?php else: ?>
                    <img class="img elevation-2 rounded-circle" src="/public/assets/dist/img/user.png" alt="User Avatar" height="20" width="20">
                    <?php endif; ?>
                  <a href="/user/<?php echo e($uuser->id); ?>"><b><?php echo e($uuser->name); ?></b></a>
                <?php if(Auth::user()->user_status == 5): ?> 
                <span class="badge badge-light" style="float:right;">
                  (<?php echo e(Carbon\Carbon::parse($uuser->last_move)->diffForHumans()); ?>)
                </span>
                <?php endif; ?>
                </p>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </div>
             </div>
            </div>
          </div>
        </div>
      </div>
    </section>
<?php $__env->stopSection(); ?>

<?php endif; ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\OpenServer2\domains\laravel7.project\resources\views/onlinelist.blade.php ENDPATH**/ ?>