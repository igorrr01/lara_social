<?php if(auth()->guard()->check()): ?>


<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
     <section class="content">
       <div class="card-header">
        <div class="row justify-content-center" >
          <div class="col-md-10">
            <!-- Box Comment -->
            <div class="card card-widget">
              <div class="card-header" >
                
                <h2 class="card-title"><b><i class="fas fa-ban"></i> Ууупс. Пользователь которого вы хотите просмотреть заблокирован за нарушение правил ресурса!</b></h2>
             

              </div>
             </div>
            </div>
          </div>
        </div>
      </div>
    </section>

<?php $__env->stopSection(); ?>

<?php endif; ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\OpenServer2\domains\laravel7.project\resources\views/layouts/blocked.blade.php ENDPATH**/ ?>