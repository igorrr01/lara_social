<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Tvinky</title>
    <?php echo $__env->make('layouts.alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <!-- Google Font: Source Sans Pro -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="<?php echo e(asset('public/assets/css/fontawesome.css')); ?>">
  <!-- icheck bootstrap -->
  <link rel="stylesheet" href="../../plugins/icheck-bootstrap/icheck-bootstrap.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="<?php echo e(asset('public/assets/css/style.css')); ?>">
    <style>
    body {background: #f7f7f7;background-image: url("public/assets/dist/img/login.jpg");font-family: -apple-system, system-ui, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;background-attachment: fixed;background-repeat: no-repeat;background-size: cover;position:relative;}
  </style>
</head>

   <div class="row justify-content-center" >
          <div class="col-md-3">

  <div class="card card-outline card-primary">
    <div class="card-header text-center">
      <img src="/public/assets/dist/img/logo.jpg" class="brand-image img-circle elevation-3" width="55" 
      style="opacity: .8">
      <a href="/" class="h1"><b>Tvinky</a>
    </div>
    <div class="card-body">
      <p class="login-box-msg">Введите данные для входа</p>

    <?php if(session('error')): ?>
                <div class="alert alert-danger">
                    <?php echo e(session('error')); ?>

                </div>
    <?php endif; ?>
    
      <form action="<?php echo e(route('login')); ?>" method="post">
       <?php echo csrf_field(); ?>
        <div class="input-group mb-3">
          <input type="email" class="form-control" placeholder="Email" id="email" name="email" value="<?php echo e(old('email')); ?>">
          <div class="input-group-append">
            <div class="input-group-text">
              <span class="fas fa-envelope"></span>
            </div>
          </div>
        </div>
        <div class="input-group mb-3">
          <input type="password" class="form-control" placeholder="Пароль" id="password" name="password" >
          <div class="input-group-append">
            <div class="input-group-text">
              <span class="fas fa-lock"></span>
            </div>
          </div>
        </div>
          <div class="col-15" >
            <button type="submit" class="btn btn-block btn-primary">Войти</button>
          </div>
          <!-- /.col -->
        </div>
      </form>
      <hr>

      <div class="card-footer">
      <p class="mb-0">
      <i class="fas -solid fa-user-plus"></i>
        <a href="<?php echo e(route('user.create')); ?>" class="text-center"> Регистрация</a>
      </p>
      <i class="fas fa-users "></i>
        <a href="<?php echo e(route('password.request')); ?>">Восстановить пароль</a>
      </p>
    </div>


<!-- /.login-box -->

<div class="card-body">
      <p class="login-box-msg"><i class="fas fa-star" style="color:#7e5aa1"></i> Популярное сегодня</p>

<?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="card card-widget">
  <img class="img-fluid pad rounded" src="/storage/app/<?php echo e($p->photo); ?>" alt="Dist Photo 1">

    <span class="post-tags mb-1">
        <span class="badge badge-light"><i class="fas fa-user"></i> <?php echo e($p->description); ?></span>
      <?php $__currentLoopData = $p->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <span class="badge badge-info"> #
            <?php echo e($tag->name); ?>

          </span>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
     <span class="float-right text-muted"><i class="fas fa-heart" style="color:red"> <?php echo e(count($p->likes)); ?></i> 
        <i class="fas fa-comments" style="color:blue"> <?php echo e(count($p->comments )); ?></i></span>
    </span>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</div>


  </div></div>
    <!-- /.login-card-body -->
  </div>
</div>
</b>
</a></div>

<!-- jQuery -->
<script src="../../plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap 4 -->
<script src="../../plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- AdminLTE App -->
<script src="../../dist/js/adminlte.min.js"></script>
</html>

<?php /**PATH E:\OpenServer2\domains\laravel7.project\resources\views/login.blade.php ENDPATH**/ ?>