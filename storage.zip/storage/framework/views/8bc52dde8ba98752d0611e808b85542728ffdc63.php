<?php if(auth()->guard()->check()): ?>


<?php $__env->startSection('content'); ?>

    <!-- Main content -->
    <section class="content">
    <div class="card-header">
        <div class="row justify-content-center" >
          <div class="col-md-10">
            <!-- Box Comment -->
            <div class="card card-widget">
              <div class="card-header">
                <div class="user-block">
                  <?php if($posts->user->avatar): ?>
                  <img class="img-circle" src="/storage/app/<?php echo e($posts->user->avatar); ?>" alt="User Image">
                  <?php else: ?>
                  <img class="img-circle" src="/public/assets/dist/img/user.png" alt="User Image">
                  <?php endif; ?>
                  <span class="username"><a href="#"></a></span>
                  <!-- Randbages color -->
                   <?php 
                     $inputbages = ['primary','secondary','success','danger','warning','info','light','dark'];
                     $randbages = array_rand($inputbages, 2);
                     $randbages =  $inputbages[$randbages[0]]; 
                   ?>
                   <!-- /.Randbages color -->
                  <span class="description"><h6><span class="badge badge-<?php echo e($randbages); ?>"><a href="/user/<?php echo e($posts->user->id); ?>" style="color: #ffffff"><?php echo e($posts->user->name); ?></a></span>
                    <?php if($posts->user->verify == '1'): ?>
                      <i class="bi bi-patch-check-fill" style="color: blue"></i></h6></span>
                    <?php endif; ?>
                  </h6></span>
                </div>
                <!-- /.user-block -->
                <div class="card-tools">
                  <span class="description" style="color: #343a40">
                    <?php if(Auth::user()->user_status == 5 || Auth::user()->id == $posts->user_id): ?> 
                    <a href="/post/delete/<?php echo e($posts->id); ?>" ><i class="fas fa-trash-alt"></i></a> 
                    <?php endif; ?>
                  <small><?php echo e(Carbon\Carbon::parse($posts->post_time)->diffForHumans()); ?></small></span>
                </div>
                <!-- /.card-tools -->
              </div>
              <!-- /.card-header -->
            <div class="card-body">
                <a href="/post/view/<?php echo e($posts->id); ?>"><img class="img-fluid pad rounded"  src="/storage/app/<?php echo e($posts->photo); ?>" alt="Photo"></a><p></p>
                  <?php if($posts->user->avatar): ?>
                  <img class="direct-chat-img" src="/storage/app/<?php echo e($posts->user->avatar); ?>" alt="User Image">
                  <?php else: ?>
                  <img class="direct-chat-img" src="/public/assets/dist/img/user.png" alt="User Image">
                  <?php endif; ?>

                  <div class="direct-chat-text" style="background-color: #ffffff;">
                      
                   <?php echo e($posts->description); ?> </div><p></p>
                <a href="/post/like/<?php echo e($posts->id); ?>">

                    <?php if($posts->likes_count >= 1): ?>

                  <?php $__currentLoopData = $posts->likes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $like): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if(Auth::user()->id == $like->user_id): ?>
                      <button type="button" class="btn btn-default btn-sm"><i class="fas fa-heart" style="color:red"> <?php echo e(count($posts->likes)); ?></i></button></a>
                      <?php break; ?>;
                    <?php endif; ?>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php if(Auth::user()->id != $like->user_id): ?>
                      <button type="button" class="btn btn-default btn-sm"><i class="far fa-heart" style="color:red"> <?php echo e(count($posts->likes)); ?></i></button></a>
                    <?php endif; ?>
                    <?php else: ?>
                      <button type="button" class="btn btn-default btn-sm"><i class="far fa-heart" style="color:red"> <?php echo e(count($posts->likes)); ?></i></button></a>
                    <?php endif; ?>

                <span class="float-right text-muted"><i class="fas fa-heart" style="color:red"> <?php echo e(count($posts->likes)); ?></i> (<a href="/post/wholike/<?php echo e($posts->id); ?>">?</a>) 
                  <i class="fas fa-comments" style="color:blue"> <?php echo e(count($posts->comments )); ?></i></span>

                        <div class="post-tags mb-4">
                            <?php $__currentLoopData = $posts->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <div class="badge badge-info"> #
                                <a href="/tags/<?php echo e($tag->name); ?>" style="color: #ffffff"><?php echo e($tag->name); ?></a></div>
                             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
               <div class="card-footer card-comments">
            <?php if(count($posts->comments_post) >= 1): ?>
            <?php $c = 1; ?>
            <?php $__currentLoopData = $posts->comments_post; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <!-- /.card-body -->
                <div class="card-comment">
                  <!-- User image -->
                  <?php if($comment->user->avatar): ?>
                  <img class="img-circle img-sm" src="/storage/app/<?php echo e($comment->user->avatar); ?>" alt="User Image">
                  <?php else: ?>
                  <img class="img-circle img-sm" src="/public/assets/dist/img/user.png" alt="User Image">
                  <?php endif; ?>
                  <div class="comment-text">
                    <span class="username">
                      <a href="/user/<?php echo e($comment->user->id); ?>"><?php echo e($comment->user->name); ?></a>
                      <span class="text-muted float-right">

                    <?php if(Auth::user()->user_status == 5 || Auth::user()->id == $comment->user_id): ?> 
                    <a href="/post/deleteComment/<?php echo e($comment->id); ?>" ><i class="fas fa-trash-alt"></i></a> 
                    <?php endif; ?>

                        <?php echo e(Carbon\Carbon::parse($comment->comment_time)->diffForHumans()); ?></span>
                    </span><!-- /.username -->
                    <?php echo e($comment->comment); ?>

                  </div>
                  <!-- /.comment-text -->
                </div>

              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <?php endif; ?>
            </div>
              <!-- /.card-footer -->
              <div class="card-footer">
                <form action="/post/comment/<?php echo e($posts->id); ?>" method="post">
                  <?php echo csrf_field(); ?>
                  <?php if(Auth::user()->avatar): ?>
                  <img class="img-fluid img-circle img-sm" src="/storage/app/<?php echo e(Auth::user()->avatar); ?>" alt="Alt Text">
                  <?php else: ?>
                  <img class="img-fluid img-circle img-sm" src="/public/assets/dist/img/user.png" alt="Alt Text">
                  <?php endif; ?>
                  <!-- .img-push is used to add margin to elements next to floating images -->
                  <div class="img-push">
                    <p class="lead emoji-picker-container">
                    <input type="text" class="form-control form-control-sm" name="comment" placeholder="Введите комментарий..." data-emojiable="true" data-emoji-input="unicode"></p>
                      <span style="float:right;">
                        <div class="mt-2" >
                          <button type="submit" class="btn btn-block btn-primary">Отправить</button> 
                        </span>
                      </div>
                  </div>
                </form>
              </div>
          </div>
              <!-- /.card-footer -->
            </div>
            <!-- /.card -->
          </div>
          <!-- /.col -->


        </div>
      </section>

<?php $__env->stopSection(); ?>
<?php endif; ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\OpenServer2\domains\laravel7.project\resources\views/post/view.blade.php ENDPATH**/ ?>