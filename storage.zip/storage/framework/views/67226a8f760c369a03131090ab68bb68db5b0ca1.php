
<div id="imageModalBox" class="imageModal">
    <span class="imageModal-close">&times;</span>
    <img class="imageModal-content" id="imageModalBoxSrc">
  </div>

  
  <div class="app-modal" data-name="delete">
      <div class="app-modal-container">
          <div class="app-modal-card" data-name="delete" data-modal='0'>
              <div class="app-modal-header">Вы уверены в удалении?</div>
              <div class="app-modal-body">Ошибка</div>
              <div class="app-modal-footer">
                  <a href="javascript:void(0)" class="app-btn cancel">Отмена</a>
                  <a href="javascript:void(0)" class="app-btn a-btn-danger delete">Удалить</a>
              </div>
          </div>
      </div>
  </div>
  
  <div class="app-modal" data-name="alert">
      <div class="app-modal-container">
          <div class="app-modal-card" data-name="alert" data-modal='0'>
              <div class="app-modal-header"></div>
              <div class="app-modal-body"></div>
              <div class="app-modal-footer">
                  <a href="javascript:void(0)" class="app-btn cancel">Отмена</a>
              </div>
          </div>
      </div>
  </div>
  
  <div class="app-modal" data-name="settings">
      <div class="app-modal-container">
          <div class="app-modal-card" data-name="settings" data-modal='0'>
              <form id="update-settings" action="<?php echo e(route('avatar.update')); ?>" enctype="multipart/form-data" method="POST">
                  <?php echo csrf_field(); ?>
                  
                  
                      
                      <p class="divider"></p>
                      <p class="app-modal-header">Ночной режим <span class="
                        <?php echo e(Auth::user()->dark_mode > 0 ? 'fas' : 'far'); ?> fa-moon dark-mode-switch"
                         data-mode="<?php echo e(Auth::user()->dark_mode > 0 ? 1 : 0); ?>"></span></p>
                      
                      <p class="divider"></p>
                      
                      <div class="update-messengerColor">
                      <?php $__currentLoopData = config('chatify.colors'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $color): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <span style="background-color: <?php echo e($color); ?>" data-color="<?php echo e($color); ?>" class="color-btn"></span>
                        <?php if(($loop->index + 1) % 5 == 0): ?>
                            <br/>
                        <?php endif; ?>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </div>
                  </div>
                  <div class="app-modal-footer">
                      <a href="javascript:void(0)" class="app-btn cancel">Отмена</a>
                      <input type="submit" class="app-btn a-btn-success update" value="Сохранить изменения" />
                  </div>
              </form>
          </div>
      </div>
  </div>
<?php /**PATH E:\OpenServer2\domains\laravel7.project\resources\views/vendor/Chatify/layouts/modals.blade.php ENDPATH**/ ?>