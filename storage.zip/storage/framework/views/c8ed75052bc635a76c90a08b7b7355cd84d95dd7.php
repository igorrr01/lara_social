<?php if(auth()->guard()->check()): ?>


<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

     <section class="content">
       <div class="card-header">
        <div class="row justify-content-center" >
          <div class="col-md-10">
            <!-- Box Comment -->
            <div class="card card-widget">
              <div class="card-header" style="background: #c9e0f2">
                <h2 class="card-title"><b><i class="far fa-bell"></i> Уведомления</b></h2></div>
                <div class="card-header">
                <h2 class="card-title"><b><i class="fas fa-users mr-2"></i>Подписчики</b></h2>
                <small><span style="float:right"><i class="fas fa-user-clock"> последние 50</i></span></small></div>
                  <div class="card-footer card-comments " style="background: #fefaff">
                  <?php $__currentLoopData = $foll; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fol): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php $c = 1; ?>
                  <?php $__currentLoopData = $fol->followers->reverse(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <div class="card-comment" >
                      <?php if($fo->avatar): ?>
                      <img class="img-circle img-sm" src="/storage/app/<?php echo e($fo->avatar); ?>" alt="User Image">
                      <?php else: ?>
                      <img class="img-circle img-sm" src="/public/assets/dist/img/user.png" alt="User Image">
                      <?php endif; ?>
                       <div class="comment-text">
                      <span class="username">
                      <a href="/user/<?php echo e($fo->id); ?>"><?php echo e($fo->name); ?></a>  
                      <small><i class="fas fa-user-plus"></i> подписался на Вас
                      <span style="float:right"><i class="fas fa-clock"></i> <?php echo e($fo->pivot->created_at); ?></span></small>
                      </span>
                    </div>
                  </div>
                <?php if($c >=50) break; ++$c; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </div>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 


              <div class="card-header">
              <h2 class="card-title"><b><i class="fas fa-heart mr-2" ></i>Likes</b></h2>
              <small><span style="float:right"> последние 5 постов ( <i class="fas fa-heart"></i> 25 ) </span></small></div>
              <div class="card-footer card-comments " style="background: #fefaff">
                  <?php $c = 1; ?>
                  <?php $__currentLoopData = $like; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $likes): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="card-header">
              <a href="/post/view/<?php echo e($likes->id); ?>"><img class="img-fluid pad" src="/storage/app/<?php echo e($likes->photo); ?>" width="50" alt="Photo"></a><br><br>
                  <?php $__currentLoopData = $likes->likes->reverse(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ll): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php $c = 1; ?>
                    <div class="card-comment" style="border-bottom:0px solid #e9ecef;padding:2px 0">
                      <?php if($ll->user->avatar): ?>
                      <img class="img-circle img-sm" src="/storage/app/<?php echo e($ll->user->avatar); ?>" alt="User Image"> 
                      <?php else: ?>
                      <img class="img-circle img-sm" src="/public/assets/dist/img/user.png" alt="User Image"> 
                      <?php endif; ?>
                        <span class="username"><a href="/user/<?php echo e($ll->user->id); ?>"><?php echo e($ll->user->name); ?></a> 
                          <small>поставил <i class="fas fa-heart mr-2" style="color:red"></i>
                          <span style="float:right"><i class="fas fa-clock"></i> <?php echo e($ll->created_at); ?></span></small>
                          </span>
                        </span>
                      </div>
                      <?php if($c >=25) break; ++$c; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </div>
                  <?php if($c >=5) break; ++$c; ?>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                </div>



           <div class="card-header">
              <h2 class="card-title"><b><i class="fas fa-comments mr-2" ></i>Комментарии</b></h2>
              <small><span style="float:right"> последние 5 постов ( <i class="fas fa-comments"></i> 25 ) </span></small></div>
              <div class="card-footer card-comments " style="background: #fefaff">
                  <?php $c = 1; ?>
                  <?php $__currentLoopData = $like; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $likes): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="card-header">
              <a href="/post/view/<?php echo e($likes->id); ?>"><img class="img-fluid pad" src="/storage/app/<?php echo e($likes->photo); ?>" width="50" alt="Photo"></a><br><br>
                  <?php $__currentLoopData = $likes->comments->reverse(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ll): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php $c = 1; ?>
                    <div class="card-comment" style="border-bottom:0px solid #e9ecef;padding:2px 0">
                      <?php if($ll->user->avatar): ?>
                      <img class="img-circle img-sm" src="/storage/app/<?php echo e($ll->user->avatar); ?>" alt="User Image"> 
                      <?php else: ?>
                      <img class="img-circle img-sm" src="/public/assets/dist/img/user.png" alt="User Image"> 
                      <?php endif; ?>
                        <span class="username"><a href="/user/<?php echo e($ll->user->id); ?>"><?php echo e($ll->user->name); ?></a> 
                          <small><i class="fas fa-comment"></i> <?php echo e($ll->comment); ?>

                          <span style="float:right"><i class="fas fa-clock"></i> <?php echo e($ll->created_at); ?></span></small>
                          </span>
                        </span>
                      </div>
                      <?php if($c >=25) break; ++$c; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </div>
                  <?php if($c >=5) break; ++$c; ?>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                  </div>
                </div>
             </div>
            </div>
          </div>
        </div>
      </div>
    </section>
<?php $__env->stopSection(); ?>

<?php endif; ?>

<!-- <?php $__currentLoopData = $foll; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fol): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php $__currentLoopData = $fol->followers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php if($fo->pivot->created_at->toDateTimeString() > Carbon\Carbon::createFromTimestamp(Auth::user()->notify_time)): ?>

<?php echo e($fo->name); ?><br>
<?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> -->
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\OpenServer2\domains\laravel7.project\resources\views/notify.blade.php ENDPATH**/ ?>