<?php if(auth()->guard()->check()): ?>


<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
     <section class="content">
       <div class="card-header">
        <div class="row justify-content-center" >
          <div class="col-md-10">
            <!-- Box Comment -->
            <div class="card card-widget">
              <div class="card-header">
                <h2 class="card-title"><b><i class="fas fa-heart" style="color:red"></i> Понравилось</b></h2></div>
                  <div class="card-header" >
                    <div class="card-footer card-comments " style="background: #fefaff">
                    <?php $__currentLoopData = $wholike; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $like): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <a href="/post/view/<?php echo e($like->id); ?>"><img class="img-fluid pad rounded"  src="/storage/app/<?php echo e($like->photo); ?>" alt="Photo"></a><p></p>
                      <div class="card-header">
                    <?php $__currentLoopData = $like->likes->reverse(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $likeU): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <div class="card-comment" style="border-bottom:0px solid #e9ecef;padding:2px 0">
                    <?php if($likeU->user->avatar): ?>
                     <img class="img-circle img-sm" src="/storage/app/<?php echo e($likeU->user->avatar); ?>" alt="User Image"> 
                    <?php else: ?>
                      <img class="img-circle img-sm" src="/public/assets/dist/img/user.png" alt="User Image"> 
                    <?php endif; ?>
                      <span class="username"><a href="/user/<?php echo e($likeU->user->id); ?>"><?php echo e($likeU->user->name); ?></a> 
                      <small> <i class="fas fa-heart mr-2" style="color:red"></i>
                        <span style="float:right"><i class="fas fa-clock"></i> <?php echo e($likeU->created_at); ?></span></small>
                        </span>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
              </div>
             </div>
            </div>
          </div>
        </div>
      </div>
    </section>






<?php $__env->stopSection(); ?>

<?php endif; ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\OpenServer2\domains\laravel7.project\resources\views/post/wholike.blade.php ENDPATH**/ ?>