<?php if(auth()->guard()->check()): ?>


<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
     <section class="content">
       <div class="card-header">
        <div class="row justify-content-center" >
          <div class="col-md-10">
            <!-- Box Comment -->
            <div class="card card-widget">
              <div class="card-header" >

                <h2 class="card-title"><b>Загрузка аватара</b></h2>
                 <form method="post" action="<?php echo e(route('avatar')); ?>" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="card-tools">
                  <button type="button" class="btn btn-tool" data-card-widget="collapse" title="Collapse">
                  </button>
                  <button type="button" class="btn btn-tool" data-card-widget="remove" title="Remove">
                  </button>
                </div>
              </div>
              <div class="card-body">
                Выберите изображение для загрузки
              </div>
            <?php if(Auth::user()->avatar): ?>
            <img src="/storage/app/<?php echo e(Auth::user()->avatar); ?>" alt="..." class="rounded-circle mb-2 ml-2" height="250" width="250">
            <?php endif; ?>
              <div class="custom-file col-5">
                      <input type="file" class="custom-file-input" id="avatar" name="avatar">
                      <label class="custom-file-label ml-2" for="customFile" >Выбрать файл</label>
                      <p><button type="submit" class="btn btn-primary mt-2">Загрузить</button></p>
                    </div>

              </div>
             </div>
            </div>
          </div>
        </div>
      </div>
    </section>











<?php $__env->stopSection(); ?>

<?php endif; ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\OpenServer2\domains\laravel7.project\resources\views/profile/avatar.blade.php ENDPATH**/ ?>