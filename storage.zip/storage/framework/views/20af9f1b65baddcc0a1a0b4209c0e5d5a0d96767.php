<?php if(auth()->guard()->check()): ?>


<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

     <section class="content">
       <div class="card-header">
        <div class="row justify-content-center" >
          <div class="col-md-10">
            <!-- Box Comment -->
            <div class="card card-widget">
              <div class="card-header" >
                <h2 class="card-title"><b>Рейтинг пользователей</b></h2>
                  <!-- SidebarSearch Form -->
                   <span style = "float: right">
                    <div class="form-inline">
                     <form action="<?php echo e(route('search')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                   <div class="input-group" data-widget="sidebar-search">
                    <input class="form-control form-control-sidebar" name="name" type="search" placeholder="Поиск" aria-label="Search">
                   <div class="input-group-append">
                  <button class="btn btn-sidebar">
                  <i class="fas fa-search fa-fw"></i>
                </button>
              </div>
            </div>
           </form>
          </div>
        </span>
              </div>
                  <div class="card-body">
                   <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $uuser): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <p class="card-text">
                    <?php if($uuser->avatar): ?>
                    <img src="/storage/app/<?php echo e($uuser->avatar); ?>"  alt="User Image" class="rounded-circle" height="20" width="20">
                    <?php else: ?>
                    <img class="img elevation-2 rounded-circle" src="/public/assets/dist/img/user.png" alt="User Avatar" height="20" width="20">
                    <?php endif; ?>
                  <a href="/user/<?php echo e($uuser->id); ?>"><b><?php echo e($uuser->name); ?> </b></a>
                   <span class="badge badge-light" style="float:right"><i class="fas fa-bolt" style="color: blue"></i> <?php echo e($uuser->rating); ?> %</span>
                <?php if(Auth::user()->user_status == 5): ?> 
                <span class="badge badge-light" style="float:right;">
                  (<?php echo e(Carbon\Carbon::parse($uuser->last_move)->diffForHumans()); ?>)
                </span>
                <?php endif; ?>
                </p>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </div>
             </div>
            </div>
          </div>
        </div>
      </div>
    </section>
<?php $__env->stopSection(); ?>

<?php endif; ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\OpenServer2\domains\laravel7.project\resources\views/userslist.blade.php ENDPATH**/ ?>