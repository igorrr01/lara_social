<?php if(auth()->guard()->check()): ?>


<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

     <section class="content">
       <div class="card-header">
        <div class="row justify-content-center" >
          <div class="col-md-10">
            <!-- Box Comment -->
            <div class="card card-widget">
              <div class="card-header" >
                <?php if(Auth::user()->id == $user->id): ?>
                <h2 class="card-title"><b>Ваши подписки</b></h2></div>
                <?php else: ?>
                <h2 class="card-title"><b>Подписки <a href="/user/<?php echo e($user->id); ?>"><?php echo e($user->name); ?></a></b></h2></div>
                <?php endif; ?>
                   <div class="card-footer card-comments " style="background: #fefaff">
                      <?php $__currentLoopData = $followings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $foll): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <div class="card-comment" >
                      <?php if($foll->avatar): ?>
                      <img class="img-circle img-sm" src="/storage/app/<?php echo e($foll->avatar); ?>" alt="User Image">
                      <?php else: ?>
                      <img class="img-circle img-sm" src="/public/assets/dist/img/user.png" alt="User Image">
                      <?php endif; ?>
                       <div class="comment-text">
                      <span class="username">
                      <a href="/user/<?php echo e($foll->id); ?>"><?php echo e($foll->name); ?></a>
                      </span>
                      <?php if(Auth::user()->id == $user->id): ?> <a href="/user/unfollow/<?php echo e($foll->id); ?>">Отписаться</a> <?php endif; ?>
                    </div>
                  </div>
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
              </div>
            </div>
          </div>
        </section>
<?php $__env->stopSection(); ?>

<?php endif; ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\OpenServer2\domains\laravel7.project\resources\views/profile/followings.blade.php ENDPATH**/ ?>