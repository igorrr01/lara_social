<?php if(auth()->guard()->check()): ?>


<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <?php
    if($user->user_status == '0'){
      header("Location: " . URL::to('/blocked'), true, 302);
      exit();
    }
  ?>

<div class="container col-11">
<div class="card card-widget widget-user">
              <!-- Add the bg color to the header using any of the bg-* classes -->
              <?php
              $rand_back = rand(1,42);
              ?>
              <div class="widget-user-header text-white" style="background: url('/public/assets/dist/img/themes/<?php echo e($rand_back); ?>.jpg') center center;">
              
                <h3 class="widget-user-username"><b><?php echo e($user->name); ?></b> 
                   <?php if($user->verify == '1'): ?>
                      <i class="bi bi-patch-check-fill" style="color: blue"></i>
                      <?php endif; ?></b><i class="fas fa-heart mr-2" style="color:red"></i> <?php echo e($user_like_count); ?> </h3> 
                <?php if($user->id != Auth::id()): ?>  
                <div class="widget"><a href="/public/chatify?name=<?php echo e($user->name); ?>" class="badge badge-light">Написать</a></div>
                <?php endif; ?>

                <?php if($user->firstname): ?> 
                <i class="fas fa-user-circle"></i> <?php echo e($user->firstname); ?> <?php echo e($user->lastname); ?> <br>                <?php endif; ?>
                <div class="lockscreen-item">
                <div class="lockscreen-image" style="left: -45px;">
                  <?php if($user->avatar): ?>
                  <img class="img elevation-2 rounded-circle" src="/storage/app/<?php echo e($user->avatar); ?>" alt="User Avatar" height="55" width="55">
                  <?php else: ?>
                  <img class="img elevation-2 rounded-circle" src="/public/assets/dist/img/user.png" alt="User Avatar" height="55" width="55">
                  <?php endif; ?>
                  </div>
                  <?php if($user->id != Auth::id()): ?>             
                  <div class="btn btn-block btn-default"><b>
                    <?php $__currentLoopData = $followers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $follcheck): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                    <?php if($follcheck->followers_count >= 1): ?>
                    <?php $__currentLoopData = $user->followers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $follcheck): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if(Auth::user()->id == $follcheck->id): ?>
                <h3 class="widget-user-username" >
                      <?php $rat = $user_all_count*100/$top_like_count;  ?>
                      <b><i class="fas fa-bolt" style="color: blue"></i> <?php echo e(round($rat, 1)); ?> % 
                      <span style="float:right">
                        <a href="<?php echo e(route('user.unfollow', $user->id )); ?>"><i class="fas fa-user-minus" style="color: indigo"></i></a>
                      </span></h3></b>
                       <div class="progress">
                  <div class="progress-bar bg-primary progress-bar-striped" role="progressbar" aria-valuenow="40" aria-valuemin="0" aria-valuemax="100" style="width: <?php echo e($rat); ?>%">
                  </div>
                </div>    
                <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php if(Auth::user()->id != $follcheck->id): ?>
                    <h3 class="widget-user-username" >
                      <?php $rat = $user_all_count*100/$top_like_count;  ?>
                      <b><i class="fas fa-bolt" style="color: blue"></i> <?php echo e(round($rat, 1)); ?> % 
                      <span style="float:right">
                        <a href="<?php echo e(route('user.follow', $user->id )); ?>"><i class="fas fa-user-plus" style="color: indigo"></i></a>
                      </span></h3></b>
                       <div class="progress">
                  <div class="progress-bar bg-primary progress-bar-striped" role="progressbar" aria-valuenow="40" aria-valuemin="0" aria-valuemax="100" style="width: <?php echo e($rat); ?>%">
                  </div>
                </div>
                    <?php endif; ?>
                    <?php else: ?>
                  <h3 class="widget-user-username" >
                      <?php $rat = $user_all_count*100/$top_like_count;  ?>
                      <b><i class="fas fa-bolt" style="color: blue"></i> <?php echo e(round($rat, 1)); ?> % 
                      <span style="float:right">
                        <a href="<?php echo e(route('user.follow', $user->id )); ?>"><i class="fas fa-user-plus" style="color: indigo"></i></a>
                      </span></h3></b>
                       <div class="progress">
                  <div class="progress-bar bg-primary progress-bar-striped" role="progressbar" aria-valuenow="40" aria-valuemin="0" aria-valuemax="100" style="width: <?php echo e($rat); ?>%">
                  </div>
                </div>                    <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </b>
                  </div>
                  <?php else: ?>
                  <div class="btn btn-block btn-default">
                    <h3 class="widget-user-username" >
                      <?php $rat = $user_all_count*100/$top_like_count;  ?>
                      <b><i class="fas fa-bolt" style="color: blue"></i> <?php echo e(round($rat, 1)); ?> %</h3></b>
                       <div class="progress">
                  <div class="progress-bar bg-primary progress-bar-striped" role="progressbar" aria-valuenow="40" aria-valuemin="0" aria-valuemax="100" style="width: <?php echo e($rat); ?>%">
                  </div>
                </div>
                   </div>
                  <?php endif; ?>
                </div>
              </div>                        
              <?php if($user->id != Auth::id()): ?> <hr>     <?php endif; ?>  
                <div class="row">
                  <div class="col-sm-4 border-right">
                    <div class="description-block">
                      <h5 class="description-header"><i class="fab fa-usps"></i> <?php echo e($post_count); ?> постов</h5>
                    </div>
                    <!-- /.description-block -->
                  </div>
                  <!-- /.col -->
                  <div class="col-sm-4 border-right">
                    <div class="description-block">
                      <h5 class="description-header"><i class="nav-icon fas fa-users"></i> <?php $__currentLoopData = $followers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ff): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo e($ff->followers_count); ?> 
                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                         <a href="/user/followers/<?php echo e($user->id); ?>">подписчиков</a>
                      </h5>
                    </div>
                    <!-- /.description-block -->
                  </div>
                  <!-- /.col -->
                  <div class="col-sm-4">
                    <div class="description-block">
                      <h5 class="description-header"><i class="nav-icon fas fa-user-friends"></i><?php $__currentLoopData = $followings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ff): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo e($ff->followings_count); ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      <a href="/user/followings/<?php echo e($user->id); ?>">подписок</a>
                      </h5>
                    </div>
                    <!-- /.description-block -->
                  </div>

                  <!-- /.col -->
                </div>
                                  <?php if($user->about): ?> 
                  <span style="float: left"><a class="badge badge-light">
                    <i class="fas fa-info-circle"></i> <?php echo e($user->about); ?> 
                  </a></span>
                  <?php endif; ?>
                <!-- /.row -->
            </div>

    <?php if(Auth::user()->user_status == 5): ?> 
<!--         <a href="/user/block/<?php echo e($user->id); ?>" ><i class="fas fa-trash-alt">удалить</i></a> 
 -->        
  <a href="/user/block/<?php echo e($user->id); ?>" ><i class="fas fa-ban">блокировать</i></a> 
    <?php endif; ?>
<div class="card-group">
<div class="card-columns">

<?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <div class="card">
    <a href="/post/view/<?php echo e($post->id); ?>"><img class="card-img-top rounded" src="/storage/app/<?php echo e($post->photo); ?>" alt="Card image cap"></a>
    <div class="card-body">

      <span class="post-tags mb-1">
        <i class="fas fa-user"></i><?php echo e(mb_strimwidth("$post->description", 0, 200, "...")); ?>

 
     <span class="float-right text-muted"><i class="fas fa-heart" style="color:red"> <?php echo e(count($post->likes)); ?></i> 
        <i class="fas fa-comments" style="color:blue"> <?php echo e(count($post->comments )); ?></i></span>
    </span>

      <p class="card-text"><small class="text-muted"><?php echo e(Carbon\Carbon::parse($post->post_time)->diffForHumans()); ?></small></p>

    </div>
  </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</div>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php endif; ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\OpenServer2\domains\laravel7.project\resources\views/profile/page.blade.php ENDPATH**/ ?>